//======== Copyright (c) 2017, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Red-Black Tree - public interface tests
//
// $NoKeywords: $ivs_project_1 $black_box_tests.cpp
// $Author:     Matus Janek <xjanek05@stud.fit.vutbr.cz>
// $Date:       $2017-01-04
//============================================================================//
/**
 * @file black_box_tests.cpp
 * @author Matus Janek
 * 
 * @brief Implementace testu binarniho stromu.
 */

#include <vector>

#include "gtest/gtest.h"

#include "red_black_tree.h"

class EmptyTree : public ::testing:: Test
{

protected:
    BinaryTree tree;
};

class NonEmptyTree : public ::testing:: Test
{

protected:

    virtual void setup()
    {
        int values[] = {1,2,3,4,5,6,7,8,9,10};

        for(auto value : values)
        {
            tree.InsertNode(value);
        }
    }
    BinaryTree tree;
};

class TreeAxioms : public ::testing:: Test
{

protected:

    virtual void setup()
    {
        int values[] = {1,2,3,4,5,6,7,8,9,10};

        for(auto value : values)
        {
            tree.InsertNode(value);
        }
    }
    BinaryTree tree;
};

TEST_F(EmptyTree,InsertNode)
{
    auto pair1 = tree.InsertNode(5);

    EXPECT_TRUE(pair1.first);
    EXPECT_EQ(pair1.second->key, 5);

    auto pair2 = tree.InsertNode(5);

    EXPECT_EQ(pair2.second->key, 5);
    EXPECT_FALSE(pair2.first);
    EXPECT_EQ(pair2.second,pair1.second);
}

TEST_F(EmptyTree,DeleteNode)
{   
    int key = 7;
    EXPECT_FALSE(tree.DeleteNode(key));
}

TEST_F(EmptyTree,FindNode)
{
    int key = 4;
    EXPECT_EQ(tree.FindNode(key),nullptr);
}

TEST_F(NonEmptyTree,InsertNode)
{
    this->setup();

    int existing_key = 5;

    auto node = tree.FindNode(existing_key);
    auto pair = tree.InsertNode(existing_key);

    EXPECT_FALSE(pair.first);
    EXPECT_EQ(pair.second->key,existing_key);
    EXPECT_EQ(pair.second,node);

    int non_existing_key = 11;

    auto node2 = tree.FindNode(non_existing_key);
    EXPECT_EQ(node2,nullptr);

    auto pair2 = tree.InsertNode(non_existing_key);
    EXPECT_TRUE(pair2.first);
    EXPECT_EQ(pair2.second->key,non_existing_key);

}

TEST_F(NonEmptyTree,DeleteNode)
{
    this->setup();

    int non_existing_key = 15;
    EXPECT_FALSE(tree.DeleteNode(non_existing_key));

    int existing_key = 8;
    EXPECT_TRUE(tree.DeleteNode(existing_key));
}

TEST_F(NonEmptyTree,FindNode)
{
    this->setup();

    int existing_key = 7;
    auto node = tree.FindNode(existing_key);
    EXPECT_EQ(node->key,existing_key);

    int non_existing_key = 12;
    auto node2 = tree.FindNode(non_existing_key);
    EXPECT_EQ(node2,nullptr);
}

TEST_F(TreeAxioms,Axiom1)
{
    this->setup();

    std::vector<Node_t *> vector;
    tree.GetLeafNodes(vector);
    
    for (auto v : vector)
    {
        EXPECT_EQ(v->color,tree.BLACK);
        EXPECT_EQ(v->pLeft,nullptr);
        EXPECT_EQ(v->pRight,nullptr);
        //std::cout << v->color << ' ';
    }
}

TEST_F(TreeAxioms,Axiom2)
{
    this->setup();

    std::vector<Node_t *> vector;
    tree.GetNonLeafNodes(vector);
    for(auto k : vector)
    {
        if(k->color == tree.RED)
        {
            EXPECT_EQ(k->pLeft->color,tree.BLACK);
            EXPECT_EQ(k->pRight->color,tree.BLACK);
        }
        //std::cout << k->key << ' ';
    }
}

TEST_F(TreeAxioms,Axiom3)
{
    this->setup();

    std::vector<Node_t *> leafs;
    tree.GetLeafNodes(leafs);
    auto root = tree.GetRoot();

    int current_count = 0;
    int referential_count = 0;
    bool first_iter = true;

    for(auto leaf : leafs)
    {
        auto tmp_ptr = leaf->pParent;

        while(tmp_ptr != root)
        {
            if(tmp_ptr->color == tree.BLACK)
            {
                current_count++;
            }
            tmp_ptr = tmp_ptr->pParent;
            
        }

        if(first_iter == true)
        {
            referential_count = current_count;
            first_iter = false;
        }
        EXPECT_EQ(current_count,referential_count);
        current_count = 0;
    }

}

//============================================================================//
// ** ZDE DOPLNTE TESTY **
//
// Zde doplnte testy Red-Black Tree, testujte nasledujici:
// 1. Verejne rozhrani stromu
//    - InsertNode/DeleteNode a FindNode
//    - Chovani techto metod testuje pro prazdny i neprazdny strom.
// 2. Axiomy (tedy vzdy platne vlastnosti) Red-Black Tree:
//    - Vsechny listove uzly stromu jsou *VZDY* cerne.
//    - Kazdy cerveny uzel muze mit *POUZE* cerne potomky.
//    - Vsechny cesty od kazdeho listoveho uzlu ke koreni stromu obsahuji
//      *STEJNY* pocet cernych uzlu.
//============================================================================//

/*** Konec souboru black_box_tests.cpp ***/

//======== Copyright (c) 2023, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Test Driven Development - graph
//
// $NoKeywords: $ivs_project_1 $tdd_code.cpp
// $Author:     Matus Janek <xjanek05@stud.fit.vutbr.cz>
// $Date:       $2023-03-07
//============================================================================//
/**
 * @file tdd_code.cpp
 * @author Martin Dočekal
 * @author Karel Ondřej
 *
 * @brief Implementace metod tridy reprezentujici graf.
 */

#include "tdd_code.h"


Graph::Graph(){}

Graph::~Graph(){}

std::vector<Node*> Graph::nodes() {
    std::vector<Node*> nodes;
    nodes = array_of_nodes;
    return nodes;
}

std::vector<Edge> Graph::edges() const{
    std::vector<Edge> edges;
    edges = array_of_edges;
    return edges;
}

Node* Graph::addNode(size_t nodeId) {

    for(auto actualnode : array_of_nodes)
    {
        if(actualnode->id == nodeId)
        {
            return nullptr;
        }
    }
    
    Node* inserting_node = new Node();

    inserting_node->id = nodeId;
    inserting_node->color = 0;
    array_of_nodes.push_back(inserting_node);

    return inserting_node;
}

bool Graph::addEdge(const Edge& edge){
    
    if(containsEdge(edge)==false && edge.a != edge.b)
    {
        addNode(edge.a);
        addNode(edge.b);
        array_of_edges.push_back(edge);
        return true;
    }
    return false;
}

void Graph::addMultipleEdges(const std::vector<Edge>& edges) {
    
    for(auto v : edges)
    {
        if(containsEdge(v) == false)
        {
            addEdge(v);
        }    
    }
}

Node* Graph::getNode(size_t nodeId){
    
    for(auto actualnode : array_of_nodes)
    {
        if(actualnode->id == nodeId)
        {
            return actualnode;
        }
    }
    return nullptr;
}

bool Graph::containsEdge(const Edge& edge) const{

    for(auto actual_edge : array_of_edges )
    {
        if(actual_edge == edge)
        {
            return true;
        }
    }  
    return false;
}

void Graph::removeNode(size_t nodeId){

    Node* removing_node = getNode(nodeId);
    bool found = false;
    bool found2 = false;

    for(auto actual_node = array_of_nodes.begin(); actual_node != array_of_nodes.end();)
    {
        if(*actual_node == removing_node)
        {
            array_of_nodes.erase(actual_node);

            found = true;
        }
        else
        {
         actual_node++;
        }
    }

    for(auto edge = array_of_edges.begin();edge != array_of_edges.end();)
    {
        if(edge->a == nodeId || edge->b == nodeId)
        {
            array_of_edges.erase(edge);
            found2 =true;
        }
        else
        {
            edge++;
        }       
    }

    if(found == false)
    {
        throw std::out_of_range("not found");
    }

    if(found2 == false)
    {
        throw std::out_of_range("not found");
    }
}

void Graph::removeEdge(const Edge& edge){
    
    bool found = false;

    for(auto actual_edge = array_of_edges.begin(); actual_edge !=array_of_edges.end();)
    {
        if(*actual_edge == edge)
        {
            array_of_edges.erase(actual_edge);
            found = true;
        }
        else
        {
            actual_edge++;
        }
    }

    if(found == false)
    {
        throw std::out_of_range("not found");
    }
}

size_t Graph::nodeCount() const{
    
    return array_of_nodes.size();
}

size_t Graph::edgeCount() const{
    return array_of_edges.size();
}

size_t Graph::nodeDegree(size_t nodeId) const{

    int count = 0;

    for(auto edge : array_of_edges)
    {
        if(edge.a == nodeId || edge.b == nodeId)
        {
            count++;
        }
    }

    if(count == 0)
    {
        throw std::out_of_range("not found");
    }
    return count;
}

size_t Graph::graphDegree() const{

    size_t max = 0;
    size_t referential_max = 0;
    for(auto node : array_of_nodes)
    {
        for(auto edge : array_of_edges)
        {  
            if((node->id == edge.a) || (node->id == edge.b))
            {
                max++;
            }
        }
        if(max > referential_max)
        {
            referential_max = max;
        }
        max = 0;
    }
    return referential_max;
}

void Graph::coloring(){
    // size_t max_colors = graphDegree();
    // int array_of_colors[] = {0};
    // for(int i = 0; i < max_colors; i++)
    // {
    //     array_of_colors[i] = i;
    // }
    // for(auto node: array_of_nodes)
    // {
    //     for(auto edge : array_of_edges)
    //     {
    //         if(node->id == edge.a)
    //         {
                
    //         }
    //     }
        
    // }

}

void Graph::clear() {
    array_of_edges.clear();
    array_of_nodes.clear();
}

/*** Konec souboru tdd_code.cpp ***/

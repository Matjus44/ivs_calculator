//======== Copyright (c) 2022, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     White Box - test suite
//
// $NoKeywords: $ivs_project_1 $white_box_tests.cpp
// $Author:     Matus Janek <xjanek05@stud.fit.vutbr.cz>
// $Date:       $2023-03-07
//============================================================================//
/**
 * @file white_box_tests.cpp
 * @author JMENO PRIJMENI
 *
 * @brief Implementace testu hasovaci tabulky.
 */

#include <vector>

#include "gtest/gtest.h"

#include "white_box_code.h"

class EmptyHashMap : public testing::Test
{
    void SetUp()
    {
        map = hash_map_ctor();
    }
    protected:
    hash_map_t *map;
};

class NonEmptyHashMap : public testing::Test
{
    void SetUp()
    {
        map = hash_map_ctor();
        hash_map_put(map,"exotic",1);
        hash_map_put(map,"leopard",2);
        hash_map_put(map,"idk",3);
        hash_map_put(map,"laptop",4);
        hash_map_put(map,"yack",5);
    }
    protected:
    hash_map_t *map;
};

TEST_F(EmptyHashMap,initialize)
{
    EXPECT_TRUE(map != nullptr);
    EXPECT_EQ(map->allocated,HASH_MAP_INIT_SIZE);
    EXPECT_EQ(map->used,0);
    EXPECT_TRUE(map->first == NULL);
    EXPECT_TRUE(map->last == NULL);
    EXPECT_TRUE(map->index != NULL);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap,initialize)
{
    EXPECT_TRUE(map != nullptr);
    EXPECT_EQ(map->allocated,HASH_MAP_INIT_SIZE);
    EXPECT_EQ(map->used,5);
    EXPECT_TRUE(map->first != NULL);
    EXPECT_TRUE(map->last !=NULL);
    EXPECT_TRUE(map->index != NULL);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap,ctor)
{
    hash_map_t *map2 = hash_map_ctor();
    EXPECT_TRUE(map2->first == NULL);
    EXPECT_TRUE(map2->last == NULL);
    EXPECT_TRUE(map2->index != NULL);
    EXPECT_EQ(map2->used,0);
    
    if((map2 != NULL) && (map2->index == NULL))
    {
        EXPECT_EQ(map2,nullptr);
    }
    hash_map_dtor(map);
}

TEST_F(EmptyHashMap, clear)
{
    hash_map_clear(map);
    EXPECT_EQ(map->first,nullptr);
    EXPECT_EQ(map->last,nullptr);
    EXPECT_EQ(map->used,0);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap, clear)
{
    hash_map_clear(map);
    EXPECT_EQ(map->first,nullptr);
    EXPECT_EQ(map->last,nullptr);
    EXPECT_EQ(map->used,0);
    hash_map_dtor(map);
}

TEST_F(EmptyHashMap, dtor)
{
    // hash_map_dtor(map);
    // EXPECT_EQ(map->index,nullptr);
    // EXPECT_EQ(map,nullptr);
    // EXPECT_EQ(map->allocated, 0);
    // no idea what should be here
}

TEST_F(NonEmptyHashMap, dtor)
{
    // hash_map_dtor(map);
    // EXPECT_TRUE(map->index == NULL);
    // EXPECT_TRUE(map == NULL);
    // EXPECT_TRUE(map->allocated == 0);
    // no idea what should be here
}

TEST_F(EmptyHashMap, reserve)
{
    size_t cap = hash_map_capacity(map);
    size_t cap2;
    EXPECT_EQ(cap,8);

    hash_map_reserve(map,cap*2);

    EXPECT_EQ(hash_map_capacity(map),16);
    EXPECT_EQ(hash_map_reserve(map,1),OK);
    EXPECT_EQ(hash_map_reserve(map,16),OK);

    EXPECT_EQ(map->allocated,16);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap, reserve)
{
    size_t cap = hash_map_capacity(map);
    size_t cap2;
    EXPECT_EQ(cap,8);

    hash_map_reserve(map,cap*2);

    EXPECT_EQ(hash_map_capacity(map),16);
    EXPECT_EQ(hash_map_reserve(map,1),VALUE_ERROR);
    EXPECT_EQ(hash_map_reserve(map,6),OK);
    EXPECT_EQ(hash_map_reserve(map,16),OK);

    EXPECT_EQ(map->allocated,16);
    hash_map_dtor(map);

}

TEST_F(EmptyHashMap, size)
{
    size_t amount = hash_map_size(map);
    EXPECT_EQ(amount,0);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap, size)
{
    size_t amount = hash_map_size(map);
    EXPECT_EQ(amount,5);
    hash_map_dtor(map);
}

TEST_F(EmptyHashMap, capacity)
{
    size_t cap = hash_map_capacity(map);
    EXPECT_EQ(cap,HASH_MAP_INIT_SIZE);
    hash_map_reserve(map,HASH_MAP_INIT_SIZE);
    size_t cap2 = hash_map_capacity(map);
    EXPECT_EQ(cap2,HASH_MAP_INIT_SIZE);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap, capacity)
{
    size_t cap = hash_map_capacity(map);
    EXPECT_EQ(cap,HASH_MAP_INIT_SIZE);
    hash_map_reserve(map,HASH_MAP_INIT_SIZE);
    size_t cap2 = hash_map_capacity(map);
    EXPECT_EQ(cap2,HASH_MAP_INIT_SIZE);
    hash_map_dtor(map);
}

TEST_F(EmptyHashMap, contains)
{
    bool condition = hash_map_contains(map,"exotic");
    EXPECT_FALSE(condition);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap, contains)
{
    bool condition = hash_map_contains(map,"exotic");
    EXPECT_TRUE(condition);
    bool condition2 = hash_map_contains(map,"nonexisting");
    EXPECT_FALSE(condition2);
    hash_map_dtor(map);
}

TEST_F(EmptyHashMap, put)
{
    size_t value1 = 8;
    EXPECT_EQ(hash_map_put(map,"exotic",value1),OK);
    EXPECT_EQ(hash_map_put(map,"exotic",10),KEY_ALREADY_EXISTS);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap, put)
{
    size_t value1 = 8;
    EXPECT_TRUE(hash_map_contains(map,"exotic"));
    EXPECT_EQ(hash_map_put(map,"exotic",value1),KEY_ALREADY_EXISTS);
    EXPECT_EQ(hash_map_put(map,"itsnotthere",14),OK);
    hash_map_dtor(map);
}

TEST_F(EmptyHashMap, get)
{
    int value = 8;
    EXPECT_EQ(hash_map_get(map,"exotic",&(value)),KEY_ERROR);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap, get)
{
    int value = 8;
    EXPECT_EQ(hash_map_get(map,"nonexisting",&(value)),KEY_ERROR);
    EXPECT_EQ(hash_map_get(map,"exotic",&(value)),OK);
    hash_map_dtor(map);
}

TEST_F(EmptyHashMap, pop)
{
    int value = 30;
    EXPECT_EQ(hash_map_pop(map,"exotic",&value),KEY_ERROR);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap, pop)
{
    int value = 8;
    int value2 = 30;
    hash_map_get(map,"exotic",&value);
    EXPECT_EQ(hash_map_pop(map,"exotic",&value),OK);
    EXPECT_EQ(hash_map_pop(map,"nonexisting",&value2),KEY_ERROR);
    hash_map_dtor(map);
}

TEST_F(EmptyHashMap,remove)
{
    EXPECT_EQ(hash_map_remove(map,"exotic"),KEY_ERROR);
    hash_map_dtor(map);
}

TEST_F(NonEmptyHashMap,remove)
{
    EXPECT_EQ(hash_map_remove(map,"exotic"),OK);
    EXPECT_EQ(hash_map_remove(map,"nonexisting"),KEY_ERROR);
    hash_map_dtor(map);

}

//============================================================================//
// ** ZDE DOPLNTE TESTY **
//
// Zde doplnte testy hasovaci tabulky, testujte nasledujici:
// 1. Verejne rozhrani hasovaci tabulky
//     - Vsechny funkce z white_box_code.h
//     - Chovani techto metod testuje pro prazdnou i neprazdnou tabulku.
// 2. Chovani tabulky v hranicnich pripadech
//     - Otestujte chovani pri kolizich ruznych klicu se stejnym hashem
//     - Otestujte chovani pri kolizich hashu namapovane na stejne misto v
//       indexu
//============================================================================//

/*** Konec souboru white_box_tests.cpp ***/
